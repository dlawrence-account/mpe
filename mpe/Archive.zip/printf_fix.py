if N < args.cuts * 2:
    print(f"ERROR: Series too short ({N} points) for cuts={args.cuts}")
    return