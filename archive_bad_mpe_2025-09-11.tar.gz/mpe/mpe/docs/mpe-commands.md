# MPE Command Reference

**cd-mpe**  
Jump to the repo root and show status.

**cd-mpe --force**  
Jump to repo root and allow risky actions (with confirmation).

**go-mpe**  
Show repo status from anywhere.

**go-mpe --force**  
Show status and allow risky actions (with confirmation).

**mpe-help**  
Show this cheat sheet.

**mpe-test**  
Run branch safety and help display tests.

**mpe-test --summary [N]**  
Show the last N test runs with PASS/FAIL counts and a health bar.

