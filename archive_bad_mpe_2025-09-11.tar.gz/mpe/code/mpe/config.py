# mpe/code/mpe/config.py
DATA_DIR = "data"
DEFAULT_TRIPLE = (0.5, 0.2, 1.0)
DEFAULT_K = 3
